package com.cp.sports.Exception;

public class PaymentServiceException extends RuntimeException{

	public PaymentServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
