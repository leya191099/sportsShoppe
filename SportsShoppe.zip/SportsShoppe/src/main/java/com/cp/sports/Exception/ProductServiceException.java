package com.cp.sports.Exception;

public class ProductServiceException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductServiceException(String msg) {
		super(msg);
	}

}